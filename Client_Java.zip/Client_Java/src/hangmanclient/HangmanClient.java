/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangmanclient;

import Hangman.Hangman_Interface;
import Hangman.Hangman_InterfaceHelper;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import org.omg.CORBA.ORB;
import org.omg.CosNaming.NameComponent;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

/**
 *
 * @author Admin
 */
public class HangmanClient extends JApplet {
    
    private static final int JFXPANEL_WIDTH_INT = 750;
    private static final int JFXPANEL_HEIGHT_INT = 500;
    private static JFXPanel fxContainer;
    private static Scene scene2;
    private static Label mysteryWord;
    private static Label dialog;
    private static Label remain;
    private static String name = "";
    private static String l = "";
    private static Button btnPlay;
    private static Label pname;
    private static Label hangman;
    private static int count;
    private static StackPane root;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
                } catch (Exception e) {
                }
                JFrame frame = new JFrame("Hang-Me-Not");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
                JApplet applet = new HangmanClient();
                applet.init();
                
                frame.setContentPane(applet.getContentPane());
                
                frame.pack();
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                applet.start();
            }
        });
    } 
   	static List<String> usedLetter = new ArrayList<String>();
	static List<String> wordArray = new ArrayList<String>();
	static List<String> showWord = new ArrayList<String>();
    
    public static void clearAll() {
		usedLetter.clear();
		wordArray.clear();
		showWord.clear();
	}

	public static void checkIfWin() {
            if(!showWord.contains("_")) {
                Alert logout = new Alert(AlertType.INFORMATION);
                    logout.setTitle("Information Dialog");
                    logout.setHeaderText(null);
                    logout.setContentText("Congratulations! You have guessed the word.");
                    logout.showAndWait();
                tryAgain(null);
                enableButtons();
		}
	}

	public static boolean displayWord(String letter) {
		if(wordArray.contains(letter)) {
                    for(int z = 0; z < wordArray.size(); z++) {
                        if(wordArray.get(z).equals(letter)) {
                            showWord.set(z, letter);
                        }
                    }
                    return true;
		}
		return false;
	}

	public static void tryAgain(String[] args) {
            String name_service="Hangman_game";
            try{
                ORB orb = ORB.init(args, null); 
                org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
                NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef); 
                NameComponent nc = new NameComponent(name_service, "");
                NameComponent path[] = {nc};
                Hangman_Interface hm= Hangman_InterfaceHelper.narrow(ncRef.resolve(path));
                word = "";
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setContentText("Try Again?");
                Optional<ButtonType> result = alert.showAndWait();
                enableButtons();
                if (result.isPresent() && result.get() == ButtonType.OK){
                    enableButtons();
                    dialog.setText("Remaining Guess: 5");
                    remain.setText("Welcome to Hangman");
                    root.getChildren().remove(hangman);
                    image1 = new Image(HangmanClient.class.getResourceAsStream("images/0.png"));
                    hangman = new Label(null, new ImageView(image1));
                    hangman.getStyleClass().add("hangman");
                    hangman.setTranslateX(-250);
                    hangman.setTranslateY(-80);
                    root.getChildren().add(hangman);
                    wrongGuess = 5;
                    count = 0;
                    clearAll();
                    word = hm.play(name);
                    if(word.equals("NoWords")) {
                            remain.setText("No more words to be guessed.");
                            hm.logout(name);
                    }
                    hm.usedWord(name, word);
                    generateLetterList(word);
                    mysteryWord.setText(showWord.toString());

                } else {
                    Alert logout = new Alert(AlertType.INFORMATION);
                    logout.setTitle("Information Dialog");
                    logout.setHeaderText(null);
                    logout.setContentText("Thank you for playing");

                    logout.showAndWait();
                    hm.logout(name);
                    System.exit(0);
                }
                Thread.sleep(20);
            }catch(Exception er) {
                er.printStackTrace();
            }
   
	}
        
        public static void really(String[] args) {
            String name_service="Hangman_game";
            try{
                ORB orb = ORB.init(args, null); 
                org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
                NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef); 
                NameComponent nc = new NameComponent(name_service, "");
                NameComponent path[] = {nc};
                Hangman_Interface hm= Hangman_InterfaceHelper.narrow(ncRef.resolve(path));
                word = "";
                Alert alert = new Alert(AlertType.CONFIRMATION);
                alert.setContentText("Are you sure you want to quit?");
                Optional<ButtonType> result = alert.showAndWait();
                enableButtons();
                if (result.isPresent() && result.get() == ButtonType.OK){
                    Alert logout = new Alert(AlertType.INFORMATION);
                    logout.setTitle("Information Dialog");
                    logout.setHeaderText(null);
                    logout.setContentText("Thank you for playing");

                    logout.showAndWait();
                    hm.logout(name);
                    System.exit(0);
                }
                Thread.sleep(20);
            }catch(Exception er) {
                er.printStackTrace();
            }
   
	}
    
    static String str = "";
    public static void playy(String[] args){
        String name_service="Hangman_game";
		try{
			ORB orb = ORB.init(args, null); 
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef); 
			NameComponent nc = new NameComponent(name_service, "");
			NameComponent path[] = {nc};
			Hangman_Interface hm= Hangman_InterfaceHelper.narrow(ncRef.resolve(path));
			word = "";
			boolean bl = hm.login(name);
                        while(bl == false) {
                            TextInputDialog dialog = new TextInputDialog("");
                            dialog.setTitle("Hang-Me-Not");
                            dialog.setHeaderText("Hello, new player!");
                            dialog.setContentText(name+" is still in play. Please enter a different name: ");
                            Optional<String> result = dialog.showAndWait();
                            if (result.isPresent()){
                                name=result.get();
                            }
                            bl = hm.login(name);
                        }
                         wrongGuess = 5;
                            clearAll();
                            word = hm.play(name);
                            if(word.equals("NoWords")) {
                                    remain.setText("No more words to be guessed.");
                                    hm.logout(name);
                            }
                            hm.usedWord(name, word);
                            generateLetterList(word);
                            mysteryWord.setText(showWord.toString());
			
			Thread.sleep(20);
		}catch(Exception er) {
			er.printStackTrace();
		}
    }
    
    public static void generateLetterList(String word){
        for (int k = 0; k<word.length(); k++){
            wordArray.add(Character.toString(word.charAt(k)));
            showWord.add("_");
        }
    }
    
    static int wrongGuess;
    
    public static void Guess(String letter){
        if(wordArray.contains(letter)){
            for(int i = 0; i<wordArray.size();i++){
                if(wordArray.get(i).equals(letter)){
                    showWord.set(i, letter);
                }
            }
                mysteryWord.setText(showWord.toString());
                remain.setText("You have correctly guessed a letter.");
        }else{
            if(wrongGuess==1){
                count++; 
                changeImage();
                dialog.setText("Remaining guess: 0");
                remain.setText("You lose. The correct word is: "+ word);
                
                tryAgain(null);
        }else{
            count++;
            wrongGuess--;
            changeImage();
            dialog.setText("Remaining guess: " + wrongGuess);
            remain.setText("You have incorrectly guessed a letter.");
            }
        checkIfWin();
        }
        checkIfWin();
    }
    
        static Image image1;
        static String word;
    public static void changeImage(){
        if (count == 1){
            root.getChildren().remove(hangman);
            image1 = new Image(HangmanClient.class.getResourceAsStream("images/1.png"));
            hangman = new Label(null, new ImageView(image1));
                    hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
            root.getChildren().add(hangman);
            
        }
        if (count == 2){
            root.getChildren().remove(hangman);
            image1 = new Image(HangmanClient.class.getResourceAsStream("images/2.png"));
            hangman = new Label(null, new ImageView(image1));
            hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
            root.getChildren().add(hangman);
        }
        if (count == 3){
            root.getChildren().remove(hangman);
            image1 = new Image(HangmanClient.class.getResourceAsStream("images/3.png"));
            hangman = new Label(null, new ImageView(image1));
                    hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
            root.getChildren().add(hangman);
        }
        if (count == 4){
            root.getChildren().remove(hangman);
            image1 = new Image(HangmanClient.class.getResourceAsStream("images/4.png"));
            hangman = new Label(null, new ImageView(image1));
                    hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
            root.getChildren().add(hangman);
        }
        if (count == 5){
            root.getChildren().remove(hangman);
            image1 = new Image(HangmanClient.class.getResourceAsStream("images/5.png"));
            hangman = new Label(null, new ImageView(image1));
            hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
            root.getChildren().add(hangman);
            mysteryWord.setText(word);
            enableButtons();
        }
        
        
    }
    
    @Override
    public void init() {
        fxContainer = new JFXPanel();
        fxContainer.setPreferredSize(new Dimension(JFXPANEL_WIDTH_INT, JFXPANEL_HEIGHT_INT));
        add(fxContainer, BorderLayout.CENTER);
        // create JavaFX scene
        Platform.runLater(new Runnable() {
            
            @Override
            public void run() {
                createScene();
            }
        });
    }
    private static Button btnQ;
    private static Button btnW;
    private static Button btnE;
    private static Button btnR;
    private static Button btnT;
    private static Button btnY;
    private static Button btnU;
    private static Button btnI;
    private static Button btnO;
    private static Button btnP;
    private static Button btnA;
    private static Button btnS;
    private static Button btnD;
    private static Button btnF;
    private static Button btnG;
    private static Button btnH;
    private static Button btnJ;
    private static Button btnK;
    private static Button btnL;
    private static Button btnZ;
    private static Button btnX;
    private static Button btnC;
    private static Button btnV;
    private static Button btnB;
    private static Button btnN;
    private static Button btnM;
    
    private static void enableButtons(){
    btnQ.setDisable(false);
    btnW.setDisable(false);
    btnE.setDisable(false);
    btnR.setDisable(false);
    btnT.setDisable(false);
    btnY.setDisable(false);
    btnU.setDisable(false);
    btnI.setDisable(false);
    btnO.setDisable(false);
    btnP.setDisable(false);
    btnA.setDisable(false);
    btnS.setDisable(false);
    btnD.setDisable(false);
    btnF.setDisable(false);
    btnG.setDisable(false);
    btnH.setDisable(false);
    btnJ.setDisable(false);
    btnK.setDisable(false);
    btnL.setDisable(false);
    btnZ.setDisable(false);
    btnX.setDisable(false);
    btnC.setDisable(false);
    btnV.setDisable(false);
    btnB.setDisable(false);
    btnN.setDisable(false);
    btnM.setDisable(false);
    }
    
    private void createScene() {
        btnQ = new Button();
        btnQ.setText("Q");
        btnQ.setTranslateX(-265);
        btnQ.setTranslateY(75);
        btnQ.setFont(Font.font ("Century Gothic", 20));
        btnQ.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                btnQ.setDisable(true);
                Guess("q");
                
            }
        });
        
        btnW = new Button();
        btnW.setText("W");
        btnW.setTranslateX(-205);
        btnW.setTranslateY(75);
        btnW.setFont(Font.font ("Century Gothic", 20));
        btnW.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("w");
                btnW.setDisable(true);
            }
        });
        
        btnE = new Button();
        btnE.setText("E");
        btnE.setTranslateX(-145);
        btnE.setTranslateY(75);
        btnE.setFont(Font.font ("Century Gothic", 20));
        btnE.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("e");
                btnE.setDisable(true);
            }
        });
        
        btnR = new Button();
        btnR.setText("R");
        btnR.setTranslateX(-85);
        btnR.setTranslateY(75);
        btnR.setFont(Font.font ("Century Gothic", 20));
        btnR.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("r");
                btnR.setDisable(true);
            }
        });
        
        btnT = new Button();
        btnT.setText("T");
        btnT.setTranslateX(-25);
        btnT.setTranslateY(75);
        btnT.setFont(Font.font ("Century Gothic", 20));
        btnT.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("t");
                btnT.setDisable(true);
            }
        });
        
        btnY = new Button();
        btnY.setText("Y");
        btnY.setTranslateX(35);
        btnY.setTranslateY(75);
        btnY.setFont(Font.font ("Century Gothic", 20));
        btnY.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("y");
                btnY.setDisable(true);
            }
        });
        
        btnU = new Button();
        btnU.setText("U");
        btnU.setTranslateX(95);
        btnU.setTranslateY(75);
        btnU.setFont(Font.font ("Century Gothic", 20));
        btnU.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("u");
                btnU.setDisable(true);
            }
        });
        
        btnI = new Button();
        btnI.setText("I");
        btnI.setTranslateX(155);
        btnI.setTranslateY(75);
        btnI.setFont(Font.font ("Century Gothic", 20));
        btnI.getStyleClass().add("button");
        btnI.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("i");
                btnI.setDisable(true);
            }
        });
        
        btnO = new Button();
        btnO.setText("O");
        btnO.setTranslateX(215);
        btnO.setTranslateY(75);
        btnO.setFont(Font.font ("Century Gothic", 20));
        btnO.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("o");
                btnO.setDisable(true);
            }
        });
        
        btnP = new Button();
        btnP.setText("P");
        btnP.setTranslateX(275);
        btnP.setTranslateY(75);
        btnP.setFont(Font.font ("Century Gothic", 20));
        btnP.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("p");
                btnP.setDisable(true);
            }
        });
        
        btnA = new Button();
        btnA.setText("A");
        btnA.setTranslateX(-240);
        btnA.setTranslateY(135);
        btnA.setFont(Font.font ("Century Gothic", 20));
        btnA.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("a");
                btnA.setDisable(true);
            }
        });
        
        btnS = new Button();
        btnS.setText("S");
        btnS.setTranslateX(-180);
        btnS.setTranslateY(135);
        btnS.setFont(Font.font ("Century Gothic", 20));
        btnS.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("s");
                btnS.setDisable(true);

            }
        });
        
        btnD = new Button();
        btnD.setText("D");
        btnD.setTranslateX(-120);
        btnD.setTranslateY(135);
        btnD.setFont(Font.font ("Century Gothic", 20));
        btnD.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("d");
                btnD.setDisable(true);

            }
        });
        
        btnF = new Button();
        btnF.setText("F");
        btnF.setTranslateX(-60);
        btnF.setTranslateY(135);
        btnF.setFont(Font.font ("Century Gothic", 20));
        btnF.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("f");
                btnF.setDisable(true);
            }
        });
        
        btnG = new Button();
        btnG.setText("G");
        btnG.setTranslateX(0);
        btnG.setTranslateY(135);
        btnG.setLayoutY(355);
        btnG.setFont(Font.font ("Century Gothic", 20));
        btnG.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("g");
                btnG.setDisable(true);
            }
        });
        
        btnH = new Button();
        btnH.setText("H");
        btnH.setTranslateX(60);
        btnH.setTranslateY(135);
        btnH.setFont(Font.font ("Century Gothic", 20));
        btnH.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("h");
                btnH.setDisable(true);
            }
        });
        
        btnJ = new Button();
        btnJ.setText("J");
        btnJ.setTranslateX(120);
        btnJ.setTranslateY(135);
        btnJ.setFont(Font.font ("Century Gothic", 20));
        btnJ.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("j");
                btnJ.setDisable(true);
            }
        });
        
        btnK = new Button();
        btnK.setText("K");
        btnK.setTranslateX(180);
        btnK.setTranslateY(135);
        btnK.setFont(Font.font ("Century Gothic", 20));
        btnK.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("k");
                btnK.setDisable(true);
            }
        });
        
        btnL = new Button();
        btnL.setText("L");
        btnL.setTranslateX(240);
        btnL.setTranslateY(135);
        btnL.setFont(Font.font ("Century Gothic", 20));
        btnL.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("l");
                btnL.setDisable(true);
            }
        });
        
        btnZ = new Button();
        btnZ.setText("Z");
        btnZ.setTranslateX(-175);
        btnZ.setTranslateY(195);
        btnZ.setFont(Font.font ("Century Gothic", 20));
        btnZ.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("z");
                btnZ.setDisable(true);
            }
        });
        
        btnX = new Button();
        btnX.setText("X");
        btnX.setTranslateX(-115);
        btnX.setTranslateY(195);
        btnX.setFont(Font.font ("Century Gothic", 20));
        btnX.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("x");
                btnX.setDisable(true);
            }
        });
        
        btnC = new Button();
        btnC.setText("C");
        btnC.setTranslateX(-55);
        btnC.setTranslateY(195);
        btnC.setFont(Font.font ("Century Gothic", 20));
        btnC.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("c");
                btnC.setDisable(true);
            }
        });
        
        btnV = new Button();
        btnV.setText("V");
        btnV.setTranslateX(10);
        btnV.setTranslateY(195);
        btnV.setFont(Font.font ("Century Gothic", 20));
        btnV.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("v");
                btnV.setDisable(true);
            }
        });
        
        btnB = new Button();
        btnB.setText("B");
        btnB.setTranslateX(70);
        btnB.setTranslateY(195);
        btnB.setFont(Font.font ("Century Gothic", 20));
        btnB.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("b");
                btnB.setDisable(true);
            }
        });
        btnN = new Button();
        btnN.setText("N");
        btnN.setTranslateX(130);
        btnN.setTranslateY(195);
        btnN.setFont(Font.font (20));
        btnN.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("n");
                btnN.setDisable(true);
            }
        });
        
        btnM = new Button();
        btnM.setText("M");
        btnM.setTranslateX(190);
        btnM.setTranslateY(195);
        btnM.setFont(Font.font ("Century Gothic", 20));
        btnM.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                //Code here
                Guess("m");
                btnM.setDisable(true);
            }
        });
        
        Image image = new Image(getClass().getResourceAsStream("images/0.png"));
        hangman = new Label(null, new ImageView(image));
        hangman.getStyleClass().add("hangman");
        hangman.setTranslateX(-250);
        hangman.setTranslateY(-80);
        
        pname = new Label();
        pname.setTranslateX(250);
        pname.setTranslateY(-230);
        pname.setFont(Font.font("Century Gothic", FontWeight.BOLD, 15));
        pname.getStyleClass().add("player");
        
        mysteryWord = new Label();
        mysteryWord.setTranslateX(20);
        mysteryWord.setTranslateY(-80);
        mysteryWord.setFont(Font.font("Century Gothic", FontWeight.BOLD, 30));
        mysteryWord.setStyle("-fx-text-fill: white; -fx-stroke: black; -fx-stroke-width: 2;");
        mysteryWord.setText("");
        
        dialog = new Label();
        dialog.setTranslateX(85);
        dialog.setTranslateY(15);
        dialog.setFont(Font.font("Century Gothic", 15));
        dialog.setStyle("-fx-text-fill: white;");
        dialog.setText("Remaining guess: 5");
        dialog.getStyleClass().add("dialog");
        
                remain = new Label();
        remain.setTranslateX(85);
        remain.setTranslateY(-15);
        remain.setFont(Font.font("Century Gothic", 15));
        remain.setStyle("-fx-text-fill: white;");
        remain.setText("Welcom to Hangman");
        remain.getStyleClass().add("remain");
        
        Button btnQuit2 = new Button();
        btnQuit2.setText("Quit");
        btnQuit2.setTranslateX(340);
        btnQuit2.setTranslateY(-230);
        btnQuit2.setFont(Font.font ("Century Gothic", 10));
        btnQuit2.getStyleClass().add("button-quit");
        btnQuit2.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                really(null);
            }
        });
        
        Button btnClear = new Button();
        btnClear.setText("Clear");
        btnClear.setTranslateX(340);
        btnClear.setTranslateY(-200);
        btnClear.setFont(Font.font ("Century Gothic", 10));
        btnClear.getStyleClass().add("button-quit");
        btnClear.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                enableButtons();
            }
        });
        
        root = new StackPane();
        root.getChildren().add(hangman);
        root.getChildren().add(btnQ);
        root.getChildren().add(btnW);
        root.getChildren().add(btnE);
        root.getChildren().add(btnR);
        root.getChildren().add(btnT);
        root.getChildren().add(btnY);
        root.getChildren().add(btnU);
        root.getChildren().add(btnI);
        root.getChildren().add(btnO);
        root.getChildren().add(btnP);
        root.getChildren().add(btnA);
        root.getChildren().add(btnS);
        root.getChildren().add(btnD);
        root.getChildren().add(btnF);
        root.getChildren().add(btnG);
        root.getChildren().add(btnH);
        root.getChildren().add(btnJ);
        root.getChildren().add(btnK);
        root.getChildren().add(btnL);
        root.getChildren().add(btnZ);
        root.getChildren().add(btnX);
        root.getChildren().add(btnC);
        root.getChildren().add(btnV);
        root.getChildren().add(btnB);
        root.getChildren().add(btnN);
        root.getChildren().add(btnM);
        root.getChildren().add(btnQuit2);
        root.getChildren().add(btnClear);
        root.getChildren().add(pname);
        root.getChildren().add(mysteryWord);
        root.getChildren().add(dialog);
        root.getChildren().add(remain);
//        
                scene2 = new Scene(root, 750, 500);
                
        scene2.getStylesheets().add(HangmanClient.class.getResource("style.css").toExternalForm());
        
        fxContainer.setScene(scene2);
        
        
        //MENU
        btnPlay = new Button();
        btnPlay.setText("PLAY");
        btnPlay.setLayoutX(305);
        btnPlay.setLayoutY(150);
        btnPlay.setFont(Font.font (20));
        btnPlay.getStyleClass().add("button-menu");
        btnPlay.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                TextInputDialog dialog = new TextInputDialog("");
                dialog.setTitle("Hang-Me-Not");
                dialog.setHeaderText("Hello, new player!");
                dialog.setContentText("Please enter your name: ");
                Optional<String> result = dialog.showAndWait();
                if (result.isPresent()){
                    pname.setText(result.get());
                    name=result.get();
                playy(null);
                    fxContainer.setScene(scene2);
                }
            }
        });
        
                Button btnHelp = new Button();
        btnHelp.setText("HELP");
        btnHelp.setLayoutX(305);
        btnHelp.setLayoutY(220);
        btnHelp.setFont(Font.font (20));
        btnHelp.getStyleClass().add("button-menu");
        btnHelp.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Hang-Me-Not");
                alert.setHeaderText(null);
                alert.setContentText("You will be given a word to guess. Start guessing letters until you guess the whole word. If you guessed  the word, YOU WIN! If you commit a total of five (5) mistakes before guessing the word, you will LOSE the game.");
                alert.show();
            }
        });
        
        Button btnQuit = new Button();
        btnQuit.setText("QUIT");
        btnQuit.setLayoutX(305);
        btnQuit.setLayoutY(290);
        btnQuit.setFont(Font.font (20));
        btnQuit.getStyleClass().add("button-menu");
        btnQuit.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                System.exit(0);
            }
        });
//        
        Pane menu = new Pane();  
        menu.getChildren().add(btnPlay);
        menu.getChildren().add(btnHelp);
        menu.getChildren().add(btnQuit);
        menu.getStyleClass().add("menu");
//             
        Scene scene1 = new Scene(menu, 400, 300);
        menu.getStylesheets().add(HangmanClient.class.getResource("style.css").toExternalForm());
        
        fxContainer.setScene(scene1);
//        
    }
    
    
}
